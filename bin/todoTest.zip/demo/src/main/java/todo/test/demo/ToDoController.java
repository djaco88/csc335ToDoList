package todo.test.demo;



import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.Spinner;
import javafx.scene.control.Tab;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

public class ToDoController {
    @FXML // fx:id="btnSubmit"
    private Button btnSubmit; // Value injected by FXMLLoader

    @FXML // fx:id="chkbxCompleted"
    private CheckBox chkbxCompleted; // Value injected by FXMLLoader

    @FXML // fx:id="colDate"
    private TableColumn<?, ?> colDate; // Value injected by FXMLLoader

    @FXML // fx:id="colName"
    private TableColumn<?, ?> colName; // Value injected by FXMLLoader

    @FXML // fx:id="datePicker"
    private DatePicker datePicker; // Value injected by FXMLLoader

    @FXML // fx:id="lblDueDate"
    private Label lblDueDate; // Value injected by FXMLLoader

    @FXML // fx:id="spinHour"
    private Spinner<?> spinHour; // Value injected by FXMLLoader

    @FXML // fx:id="spinMin"
    private Spinner<?> spinMin; // Value injected by FXMLLoader

    @FXML // fx:id="tab1"
    private Tab tab1; // Value injected by FXMLLoader

    @FXML // fx:id="tableNote"
    private TableView<?> tableNote; // Value injected by FXMLLoader

    @FXML // fx:id="txtTask"
    private TextArea txtTask; // Value injected by FXMLLoader

    @FXML // fx:id="txtTitle"
    private TextField txtTitle; // Value injected by FXMLLoader

    @FXML // This method is called by the FXMLLoader when initialization is complete
    void initialize() {
        assert btnSubmit != null : "fx:id=\"btnSubmit\" was not injected: check your FXML file 'TODO-FXML-Test.fxml'.";
        assert chkbxCompleted != null : "fx:id=\"chkbxCompleted\" was not injected: check your FXML file 'TODO-FXML-Test.fxml'.";
        assert colDate != null : "fx:id=\"colDate\" was not injected: check your FXML file 'TODO-FXML-Test.fxml'.";
        assert colName != null : "fx:id=\"colName\" was not injected: check your FXML file 'TODO-FXML-Test.fxml'.";
        assert datePicker != null : "fx:id=\"datePicker\" was not injected: check your FXML file 'TODO-FXML-Test.fxml'.";
        assert lblDueDate != null : "fx:id=\"lblDueDate\" was not injected: check your FXML file 'TODO-FXML-Test.fxml'.";
        assert spinHour != null : "fx:id=\"spinHour\" was not injected: check your FXML file 'TODO-FXML-Test.fxml'.";
        assert spinMin != null : "fx:id=\"spinMin\" was not injected: check your FXML file 'TODO-FXML-Test.fxml'.";
        assert tab1 != null : "fx:id=\"tab1\" was not injected: check your FXML file 'TODO-FXML-Test.fxml'.";
        assert tableNote != null : "fx:id=\"tableNote\" was not injected: check your FXML file 'TODO-FXML-Test.fxml'.";
        assert txtTask != null : "fx:id=\"txtTask\" was not injected: check your FXML file 'TODO-FXML-Test.fxml'.";
        assert txtTitle != null : "fx:id=\"txtTitle\" was not injected: check your FXML file 'TODO-FXML-Test.fxml'.";

    }

}

